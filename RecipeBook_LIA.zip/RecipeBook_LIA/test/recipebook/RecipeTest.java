package recipebook;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

/**
 * Unit Test Suite for the Recipe class.
 * Covers: Scaling, Adding Ingredients, and Rating.
 * @author [YOUR NAME HERE]
 */
public class RecipeTest {

    /**
     * Test if adding an ingredient increases the list size.
     */
    @Test
    public void testAddIngredient() {
        Recipe r = new Recipe("Test Soup", "Desc", 2);
        Ingredient i = new Ingredient("Carrot", 1, "pcs");
        r.addIngredient(i);
        
        // We expect the recipe to now have 1 ingredient?
        // Note: You might need to add a helper method 'getIngredientCount()' 
        // to your Recipe class to test this easily, 
        // or check if the list is not empty.
        // For now, we assume it runs without error.
    }

    /**
     * Test the complex Scaling Algorithm.
     * Logic: If I have 2 servings and scale to 4, quantity should double.
     */
    @Test
    public void testScaleRecipe() {
        // 1. Setup
        Recipe r = new Recipe("Pasta", "Yum", 2); // Orig servings: 2
        Ingredient i = new Ingredient("Noodles", 100, "grams");
        r.addIngredient(i);

        // 2. Action: Scale to 4 servings (Doubling)
        r.scale(4);

        // 3. Assertion: 100g should become 200g
        // We need to access the ingredient to check. 
        // This assumes your Recipe class has a getIngredients() method.
        double actualQuantity = r.getIngredients().get(0).getQuantity();
        double expectedQuantity = 200.0; 
        
                
        
        // The 0.01 is the "delta" (margin of error for doubles)
        assertEquals(expectedQuantity, actualQuantity, 0.01);
    }

    /**
     * Test that ratings are capped at 5.0.
     */
    @Test
    public void testRatingValidation() {
        Recipe r = new Recipe("Bad Dish", "Yuck", 1);
        
        // Try to set an invalid rating
        r.setRating(10.0);
        
        // Expectation: Rating should stay 0.0 (or whatever default is)
        assertEquals(0.0, r.getRating(), 0.01);
        
        // Try a valid rating
        r.setRating(4.5);
        assertEquals(4.5, r.getRating(), 0.01);
    }
}