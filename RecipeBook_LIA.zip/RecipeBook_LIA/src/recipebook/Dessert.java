package recipebook;

/**
 * A specific type of Recipe for desserts.
 * @author Kiavash
 */
public class Dessert extends Recipe {
    private boolean containsSugar;

    public Dessert(String title, String description, int servings, boolean containsSugar) {
        super(title, description, servings); // Calls the parent constructor
        this.containsSugar = containsSugar;
    }

    @Override
    public void printDetails() {
        super.printDetails(); 
        
        if (containsSugar) {
            System.out.println("\n[Note]: This dessert contains sugar.");
        } else {
            System.out.println("\n[Note]: Sugar-free!");
        }
    }
}