package recipebook;

import java.util.ArrayList;

/**
 * Represents a generic recipe.
 * @author Kiavash
 */
public class Recipe {
    private String title;
    private String description;
    private int servings;
    private ArrayList<Ingredient> ingredients;
    private ArrayList<String> instructions;
    private double rating;
    private int ratingCount; // To calculate average if needed,o

    public Recipe(String title, String description, int servings) {
        this.title = title;
        this.description = description;
        this.servings = servings;
        this.ingredients = new ArrayList<>();
        this.instructions = new ArrayList<>();
        this.rating = 0.0;
        this.ratingCount = 0;
    }

    

    public void addIngredient(Ingredient i) {
        ingredients.add(i);
    }

    public void addInstruction(String step) {
        instructions.add(step);
    }

    
    public void scale(int newServings) {
        double ratio = (double) newServings / this.servings;
        for (Ingredient i : ingredients) {
            i.setQuantity(i.getQuantity() * ratio);
        }
        this.servings = newServings;
        System.out.println("Recipe scaled to " + newServings + " servings.");
    }

    public void printDetails() {
        System.out.println("\n--- " + title.toUpperCase() + " ---");
        System.out.println("Description: " + description);
        System.out.println("Servings: " + servings + " | Rating: " + rating + "/5.0");
        
        System.out.println("\nIngredients:");
        for (Ingredient i : ingredients) {
            System.out.println(" - " + i);
        }

        System.out.println("\nInstructions:");
        for (int i = 0; i < instructions.size(); i++) {
            System.out.println((i + 1) + ". " + instructions.get(i));
        }
    }

    // --- Getters & Setters ---
    
    public String getTitle() { return title; }
    
    public void setRating(double newRating) {
        if (newRating >= 0 && newRating <= 5) {
            this.rating = newRating;
        } else {
            System.out.println("Error: Rating must be between 0 and 5.");
        }
    }
    
    public double getRating() { return rating; }
    
    
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Recipe other = (Recipe) obj;
        return this.title.equalsIgnoreCase(other.title);
    }

//    Object getIngredients() {
//        throw new UnsupportedOperationException("Not supported yet."); 
//    }
    public ArrayList<Ingredient> getIngredients() {
    return ingredients;
}
    
}