package recipebook;

import java.util.ArrayList;

/**
 * Manages a collection of recipes.
 * @author Kiavash
 */
public class RecipeBook {
    private String bookName;
    private ArrayList<Recipe> recipeList;

    public RecipeBook(String bookName) {
        this.bookName = bookName;
        this.recipeList = new ArrayList<>();
    }

    public void addRecipe(Recipe r) {
        recipeList.add(r);
        System.out.println("Recipe '" + r.getTitle() + "' added!");
    }

    public void listAllRecipes() {
        System.out.println("\n--- " + bookName + " ---");
        if (recipeList.isEmpty()) {
            System.out.println("No recipes found.");
        } else {
            for (Recipe r : recipeList) {
                System.out.println("- " + r.getTitle() + " (Rating: " + r.getRating() + ")");
            }
        }
    }

    public Recipe searchByTitle(String title) {
        for (Recipe r : recipeList) {
            if (r.getTitle().equalsIgnoreCase(title)) {
                return r;
            }
        }
        return null; 
    }
    
    
    public void listTopRated() {
        System.out.println("\n--- Top Rated Recipes (4.0+) ---");
        for (Recipe r : recipeList) {
            if (r.getRating() >= 4.0) {
                System.out.println("- " + r.getTitle());
            }
        }
    }
}