package recipebook;

import java.util.Scanner;

/**
 * The driver class with the main menu.
 * @author Kiavash
 */
public class RecipeApp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RecipeBook myBook = new RecipeBook("My Digital Cookbook");

        
        Recipe r1 = new Recipe("Pasta", "Classic tomato pasta", 2);
        r1.addIngredient(new Ingredient("Pasta", 200, "g"));
        r1.addIngredient(new Ingredient("Tomato Sauce", 1, "cup"));
        r1.addInstruction("Boil pasta.");
        r1.addInstruction("Add sauce.");
        r1.setRating(4.5);
        myBook.addRecipe(r1);
        
        Dessert d1 = new Dessert("Fruit Salad", "Fresh mix", 4, false);
        d1.addIngredient(new Ingredient("Apple", 2, "pcs"));
        d1.addInstruction("Chop fruits.");
        d1.setRating(5.0);
        myBook.addRecipe(d1);

        boolean running = true;
        while (running) {
            System.out.println("\n=== MAIN MENU ===");
            System.out.println("1. List all recipes");
            System.out.println("2. Search & View Recipe");
            System.out.println("3. Scale a Recipe");
            System.out.println("4. Rate a Recipe");
            System.out.println("5. List Top Rated");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    myBook.listAllRecipes();
                    break;
                case 2:
                    System.out.print("Enter recipe title: ");
                    String title = scanner.nextLine();
                    Recipe found = myBook.searchByTitle(title);
                    if (found != null) found.printDetails();
                    else System.out.println("Recipe not found.");
                    break;
                case 3:
                    System.out.print("Enter recipe title to scale: ");
                    String scaleTitle = scanner.nextLine();
                    Recipe toScale = myBook.searchByTitle(scaleTitle);
                    if (toScale != null) {
                        System.out.print("Enter new number of servings: ");
                        int servings = scanner.nextInt();
                        toScale.scale(servings);
                    } else {
                        System.out.println("Recipe not found.");
                    }
                    break;
                case 4:
                    System.out.print("Enter recipe title to rate: ");
                    String rateTitle = scanner.nextLine();
                    Recipe toRate = myBook.searchByTitle(rateTitle);
                    if (toRate != null) {
                        System.out.print("Enter rating (0-5): ");
                        double rating = scanner.nextDouble();
                        toRate.setRating(rating);
                        System.out.println("Rating updated!");
                    } else {
                        System.out.println("Recipe not found.");
                    }
                    break;
                case 5:
                    myBook.listTopRated();
                    break;
                case 0:
                    running = false;
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid option.");
            }
        }
        scanner.close();
    }
}